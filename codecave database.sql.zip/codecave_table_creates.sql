
-- --------------------------------------------------------

--
-- Table structure for table `creates`
--

CREATE TABLE `creates` (
  `id` int(11) NOT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `token` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `questions` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `creates`
--

INSERT INTO `creates` (`id`, `userName`, `password`, `email`, `token`, `createdAt`, `updatedAt`, `questions`) VALUES
(9, 'zin', '$2a$10$xzULVwOJZliDW0MjODx0UONKix6JVmGd1UpMybdS62I8xvuBGam0q', 'zin@zin.zin', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOjksImlhdCI6MTUyOTg3NDg0M30.Au7IhC-9f_OUbXO54QJGyuFRqwz7SNU7RxRQ4nztTaI', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ans1'),
(11, 'dev', '$2a$10$T5KbbrhwSMUW9GQFBMjUIeQXzBWMWWSZ7u52vzjoygA3eh56Th3lG', 'dev@dev.dev', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOjE3LCJpYXQiOjE1MzIxODIzOTV9.qAnDYdmHfxRtQgzahCAtlHnnJMmrw1wzhaVrvWz2eCI', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ans2'),
(12, 'abc@gmaiol', '$2a$10$HRQu8oSsuLFxtiEwWU7NGu9QFA8Ao65ubFnP22QxUfUVfoNTYiAT.', 'ATEEB@abc.com', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOjEyLCJpYXQiOjE1Mjk5NDQ0MDR9.hfF1YYq9F7tUL9FsowZcR5_-A9IYAHBJY9nWBq4nAjU', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'ans3'),
(13, 'kim', '$2a$10$tTjTbjgQuLgvOwh.k8KO/u91K0RTPKBFPGLw4BUsgj8JYXXo59b9S', 'kim@kim', 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJVc2VySUQiOjEzLCJpYXQiOjE1MzIyNzQyMjh9.zLkfl3epu9EJ25kNN1bvUCqJ4V6nROv7ZQkh-gT8gN8', '0000-00-00 00:00:00', '0000-00-00 00:00:00', ''),
(14, 'jhon', '$2a$10$fGXFGYm4iAMkuPc9nIMYpu7ZgtiKIX5he6tKM05/q4PdT89E1805C', 'jhon@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '');
