
-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(255) NOT NULL,
  `answers` longtext NOT NULL,
  `questionsID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `answers`, `questionsID`) VALUES
(101706, ',{\"ans\":\"ans1\",\"email\":\"dev@dev.dev\"},{\"ans\":\"ans2\",\"email\":\"dev@dev.dev\"},{\"ans\":\"l;akdj;la\",\"email\":\"kim@kim\"}', 46),
(101707, ',{\"ans\":\"Convert object string to JSON\",\"email\":\"dev@dev.dev\"},{\"ans\":\"al;kjdl;skfjasfdlkjfdsdfmazcxv,.mzx,.vnc.,xmcvn.zx,vmnc,.zxnvc,.xznv,xznv,xnv,xznv,.nzxv,c.nzx,.vn.,zxnv,.znxv.,nzx.,vnzx,.vnc,.zxvn,.zxnv.,xznv,.zxnv,.nxz,.vnzx,v\nal;kjdl;skfjasfdlkjfdsdfmazcxv,.mzx,.vnc.,xmcvn.zx,vmnc,.zxnvc,.xznv,xznv,xnv,xznv,.nzxv,c.nzx,.vn.,zxnv,.znxv.,nzx.,vnzx,.vnc,.zxvn,.zxnv.,xznv,.zxnv,.nxz,.vnzx,v\nal;kjdl;skfjasfdlkjfdsdfmazcxv,.mzx,.vnc.,xmcvn.zx,vmnc,.zxnvc,.xznv,xznv,xnv,xznv,.nzxv,c.nzx,.vn.,zxnv,.znxv.,nzx.,vnzx,.vnc,.zxvn,.zxnv.,xznv,.zxnv,.nxz,.vnzx,v\nal;kjdl;skfjasfdlkjfdsdfmazcxv,.mzx,.vnc.,xmcvn.zx,vmnc,.zxnvc,.xznv,xznv,xnv,xznv,.nzxv,c.nzx,.vn.,zxnv,.znxv.,nzx.,vnzx,.vnc,.zxvn,.zxnv.,xznv,.zxnv,.nxz,.vnzx,v\",\"email\":\"kim@kim\"}', 47),
(101708, ',{\"ans\":\"Just apply this {][]lkaflaknfl\",\"email\":\"kim@kim\"}', 48),
(101709, '', 49),
(101710, ',{\"ans\":\"Simple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\",\"email\":\"dev@dev.dev\"},{\"ans\":\"Simple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\nSimple Input with two items\",\"email\":\"dev@dev.dev\"}', 50),
(101711, '', 51),
(101712, '', 52),
(101713, '', 53),
(101714, '', 54),
(101715, ',{\"ans\":\"tag2\",\"email\":\"dev@dev.dev\"}', 55),
(101716, ',{\"ans\":\"You could use reduce for getting start and end part of the route and return the end for the next start.\",\"email\":\"dev@dev.dev\"},{\"ans\":\"a;ldhal;k\",\"email\":\"dev@dev.dev\"},{\"ans\":\"Another approach is to use map method in combination with slice. For map function, you have to pass a callback function as argument which will be applied for every item from your given array.\",\"email\":\"dev@dev.dev\"}', 56),
(101717, ',{\"ans\":\"You could use reduce for getting start and end part of the route and return the end for the next start.\",\"email\":\"dev@dev.dev\"},{\"ans\":\"Another approach is to use map method in combination with slice. For map function, you have to pass a callback function as argument which will be applied for every item from your given array.\",\"email\":\"kim@kim\"},{\"ans\":\"Another approach is to use map method in combination with slice. For map function, you have to pass a callback function as argument which will be applied for every item from your given array.\",\"email\":\"kim@kim\"}', 57),
(101718, ',{\"ans\":\"This should do the trick\",\"email\":\"dev@dev.dev\"},{\"ans\":\"original\",\"email\":\"dev@dev.dev\"}', 58);
