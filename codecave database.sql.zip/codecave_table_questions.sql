
-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `tags` longtext NOT NULL,
  `vote` int(11) NOT NULL,
  `dated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `email`, `title`, `question`, `tags`, `vote`, `dated`) VALUES
(57, 'dev@dev.dev', 'Convert array to array of objects with reduce', 'I want to convert optimizedRoute to result. I want to do this with ES6 .reduce(). Here is what I\'ve tried:', '[{\"display\":\"Javascript\",\"value\":\"Javascript\"},{\"display\":\"ReactJs\",\"value\":\"ReactJs\"}]', 0, '2018-07-29 11:22:23'),
(58, 'dev@dev.dev', 'How can I reverse an array in JavaScript without using libraries?', 'I am saving some data in order using arrays, and I want to add a function that the user can reverse the list. I can\'t think of any possible method, so if anybody knows how, please help.', '[{\"display\":\"Javascript\",\"value\":\"Javascript\"}]', 2, '2018-07-29 14:43:47');
